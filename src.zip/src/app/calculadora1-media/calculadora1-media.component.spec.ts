import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Calculadora1MediaComponent } from './calculadora1-media.component';

describe('Calculadora1MediaComponent', () => {
  let component: Calculadora1MediaComponent;
  let fixture: ComponentFixture<Calculadora1MediaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Calculadora1MediaComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(Calculadora1MediaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
