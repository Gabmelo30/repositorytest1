import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-calculadora1-media',
  standalone: true,
  imports: [ FormsModule, CommonModule],
  templateUrl: './calculadora1-media.component.html',
  styleUrl: './calculadora1-media.component.css'
})
export class Calculadora1MediaComponent {

  nota1: number = 0.0;
  nota2: number = 0.0;
  media: number | null = null;

  calcularMedia(): void {
    this.media =(this.nota1 + this.nota2) / 2;
  }
}
